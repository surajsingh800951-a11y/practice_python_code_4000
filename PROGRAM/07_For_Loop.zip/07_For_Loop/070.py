# 70. Print alphabets from a to z.
for i in range(97,123):
    print(chr(i))