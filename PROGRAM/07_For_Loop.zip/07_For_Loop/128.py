# 128. Find all factors of a number.
n=int(input("Enter a number = "))
for i in range(1,n+1):
    if n % i == 0:
        print("Factors =",i)
