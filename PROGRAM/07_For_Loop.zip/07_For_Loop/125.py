# 125. Print all prime numbers from 1 to 100.
for i in range(1,101):
    count=0
    for j in range(1,i+1):
        if count > 2:
            break
        if i % j == 0:
            count+=1
    if count == 2 :
        print("Prime number =",i)