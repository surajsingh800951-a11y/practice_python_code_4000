# 55. Print a hollow square pattern.
'''
*****
*   *
*   *
*   *
*****
'''
n=int(input("Enter a number = ")) # 5
for i in range(1,n+1):
    for j in range(1,n+1):
        if i==1 or i==n or j==1 or j==n:
            print("*",end="")
        else:
            print(" ",end="")
    print()