# 64. Print Floyd's Triangle.
'''
1
2 3
4 5 6
7 8 9 10
11 12 13 14 15
'''
#n=int(input("Enter a number = "))
n=5
s=1
for i in range(1,n+1):
    for j in range(i):
        print(s,end=" ")
        s+=1
    print()
        